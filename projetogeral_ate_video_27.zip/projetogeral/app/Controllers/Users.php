<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UsersModel;

class Users extends BaseController
{
    private $sessao;
    public function __construct()
    {
        $this->sessao = session();
    }
    public function index()
    {
        if ($this->check_sessao()) {
            //echo 'sessão ativa';
            $this->homePage();
        } else {
            $this->login();
        }
    }

    public function login()
    {

        if ($this->check_sessao()) {
            //Se existe sessão, vai para a página inicial homePage
            $this->homePage();
            return;
        }

        $error = "";
        $data = array();
        $request = \Config\Services::request();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            $username = $request->getPost('text_username');
            $password = $request->getPost('text_password');

            if ($username == '' || $password == '') {
                $error = "preencha os campos corretamente";
            }
            //check database
            if ($error == '') {
                $model = new UsersModel();
                $result = $model->verifyLogin($username, $password);
                if (is_array($result)) {
                    $this->setSession($result);
                    $this->homePage();
                    return;
                } else {
                    //login inválido
                    //echo 'Not OK';
                    $error = 'Login inválido';
                    //echo $error;
                }
                //  exit();
            }
        }

        if ($error != '') {
            $data['error'] = $error;
        }
        echo view('users/login', $data);
    }


    //--------------------------------------------------------------------
    private function setSession($data)
    {
        //define session
        $session_data = array(
            'id_user' => $data['id_user'],
            'name' => $data['name']
        );

        $this->sessao->set($session_data);
    }
    //--------------------------------------------------------------------
    public function homePage()
    {
        //verifica se a sessão existe
        if (!$this->check_sessao()) {
            $this->login();
            return;
        }
        //mostra a página Home
        echo view('users\homepage');
    }

    //--------------------------------------------------------------------
    public function logout()
    {
        //logout
        $this->sessao->destroy();
        // $this->index();
        return redirect()->to(site_url('users'));
    }
    //--------------------------------------------------------------------

    private function check_sessao()
    {
        return $this->sessao->has('id_user');
    }
    //--------------------------------------------------------------------
    public function recover()
    {
        // mostra formulário para recuperação da senha
        echo view('users/recover_password');
    }
    //--------------------------------------------------------------------
    public function reset_password()
    {
        //  MÉTODO 1))))))))))))))))))))))))))))))))))))
        //reset senha
        // $request = \Config\Services::request();
        // $email = $request->getPost('text_email');
        // //verifica se há usuário com esse email
        // $users = new UsersModel();
        // $users->resetPassword($email);
        //FIM MÉTODO 1 )))))))))))))))))))))))))))))))))

        //MÉTODO 2 ===================================
        $request = \Config\Services::request();
        $email = $request->getPost('text_email');
        $users = new UsersModel();
        //checa email método 2
        $result = ($users->checkEmail($email));
        if (count($result) != 0) {
            //existe email  
            //PURL = personnal URL 
            $users->sendPulr($email, $result[0]['id_user']);
            echo 'existe email';
        } else {
            //não existe email
            echo 'email não é do ID';
        }
    }
    //--------------------------------------------------------------------
    public function redefine_password($purl)
    {
        $users = new UsersModel();
        $results = ($users->getPurl($purl));
        if (count($results) != 0) {
            //existe purl  
            //PURL = personnal URL 
      //      $users->sendPulr($email, $result[0]['id_user']);
         //   echo 'existe purl';
            //die("existe purl");
            $data['user'] = $results[0];

        echo view('users/redefine_password', $data);

        } else {
            //não existe purl   
            return redirect()->to(site_url('main'));
            //echo 'purl não é do ID';
           // die("não existe purl");
        }
    }
    //--------------------------------------------------------------------

    public function redefine_password_submit(){
        $request = \Config\Services::request();
        $id_user = $request->getPost('text_id_user');
        $nova_password = $request->getPost('text_nova_password');
        $nova_password_repetida = $request->getPost('text_repetir_password');
        //verifica se as senhas digitadas são iguais
        $error = '';
        if ($nova_password != $nova_password_repetida){
            $error = "senhas não conferem";
            die($error);
        }
        if ($error == ''){
            $users = new UsersModel();
            $users->redefinePassword($id_user, $nova_password);

        }

        
                        

    }
}
