/* esconde erro */
console.log('1');
$('#error-message').delay(2000).fadeOut('slow');
