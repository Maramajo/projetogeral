<?php

return [
   'languageGetLineInvalidArgumentException' => 'Whatever this would be, translated',
];
